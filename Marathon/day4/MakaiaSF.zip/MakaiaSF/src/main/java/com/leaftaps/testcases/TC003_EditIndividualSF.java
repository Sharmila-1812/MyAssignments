package com.leaftaps.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.SFLoginPage;

public class TC003_EditIndividualSF extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "SFEditIndividual";
		testDescription ="verify whether the existing individual has been edited";
		authors="Sharmila";
		category ="Functional";
		excelFileName="EditIndi";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String uname,String pass,String lastName,String updateFirstName) throws InterruptedException {
	SFLoginPage lp=new SFLoginPage();
	lp.enterUsername(uname)
	.enterPassword(pass)
	.clickLogin()
	.verifyHomePage()
	.clickToggleMenu()
	.clickViewAll()
	.clickIndividuals()
	.clickIndividualsTab()
	.searchList(lastName)
	.clickRowActionsDD()
	.clickEditAction()
	.updateSalutationDD()
	.updateFirstName(updateFirstName)
	.clickSaveButton()
	.verifyMessage(updateFirstName);
	
	}

}
