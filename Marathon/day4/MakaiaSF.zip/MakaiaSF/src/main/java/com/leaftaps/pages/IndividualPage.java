package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class IndividualPage  extends ProjectSpecificMethods{
	public IndividualPage clickIndividualDropdown() {
		click(locateElement(Locators.XPATH, "//div[@class='slds-context-bar__label-action slds-p-left_none slds-p-right_x-small']//a"));
		reportStep("Individuals Dropdown is clicked successfully", "pass");
		return this;
	}
	
	public CreateNewIndividualPage clickNewIndividual() {
		executeTheScript("arguments[0].click();", locateElement(Locators.XPATH, "//span[text()='New Individual']"));
		reportStep("Click New Individual is clicked successfully", "pass");
		return new CreateNewIndividualPage();
	}
	
	public IndividualPage clickIndividualsTab() {
		executeTheScript("arguments[0].click();", locateElement(Locators.XPATH, "//a[@title='Individuals']//span[1]"));
		reportStep("Click Individuals is clicked successfully", "pass");
		return this;
	}
	
	public IndividualPage searchList(String lName) {
		typeAndEnter(locateElement(Locators.XPATH, "//input[@name='Individual-search-input']"),lName);
		reportStep("Search List is typed successfully", "pass");
		return this;
	}
	
	public IndividualPage clickRowActionsDD() throws InterruptedException {
		Thread.sleep(3000);
		click(locateElement(Locators.XPATH, "//div[@class='forceVirtualActionMarker forceVirtualAction']/a[@role='button']"));
		reportStep("Row Action Dropdown is clicked successfully", "pass");
		return this;
	}
	
	public EditIndividualPage clickEditAction(){
		executeTheScript("arguments[0].click();", locateElement(Locators.XPATH, "//a[@title='Edit']/div"));
		reportStep("Edit Action is clicked successfully", "pass");
		return new EditIndividualPage();
	}
	
	
	
	/*
	 * public CreateLeadPage enterCompanyName(String comName) {
	 * clearAndType(locateElement(Locators.XPATH,
	 * "//input[@id='createLeadForm_companyName']"), comName);
	 * reportStep(comName+" company name is entered successfully","pass"); return
	 * this; } public CreateLeadPage enterFirstName(String fName) {
	 * clearAndType(locateElement(Locators.ID, "createLeadForm_firstName"), fName);
	 * reportStep(fName+" first name is entered successfully","pass"); return this;
	 * }
	 */
	


}
