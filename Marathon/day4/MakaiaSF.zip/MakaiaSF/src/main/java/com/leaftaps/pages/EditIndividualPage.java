package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class EditIndividualPage extends ProjectSpecificMethods {
	
	
	public EditIndividualPage updateSalutationDD() {
		click(locateElement(Locators.XPATH, "//a[@class='select']"));
		click(locateElement(Locators.XPATH, "//a[text()='Ms.']"));	
		reportStep("Salutation is updated successfully", "pass");
		return this;
	}
	
	public EditIndividualPage updateFirstName(String fName) {
		clearAndType(locateElement(Locators.XPATH, "//input[contains(@class,'firstName')]"), fName);
		reportStep(fName+" First name is updated successfully","pass");
		return this;
	}
	
	public ViewIndividualPage clickSaveButton() {
		click(locateElement(Locators.XPATH, "(//span[text()='Save'])[2]"));
		reportStep("Save is clicked successfully", "pass");
		return new ViewIndividualPage();
	}
	
	
	

}
