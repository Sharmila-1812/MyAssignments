package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class SFHomePage extends ProjectSpecificMethods {

	public SFHomePage verifyHomePage() {

		verifyDisplayed(locateElement(Locators.XPATH, "//div[@class='slds-icon-waffle']"));
		reportStep("Homepage is loaded", "pass");
		return this;
	}

	public SFHomePage clickToggleMenu() {
		click(locateElement(Locators.XPATH, "//div[@class='slds-icon-waffle']"));
		reportStep("Toggle Menu is clicked", "pass");
		return this;
	}

	public SFHomePage clickViewAll() {
		click(locateElement(Locators.XPATH, "//button[text()='View All']"));
		reportStep("View All Link is clicked", "pass");
		return this;
	}

	public IndividualPage clickIndividuals() {
		executeTheScript("arguments[0].scrollIntoView();", locateElement(Locators.XPATH, "//p[text()='Party Consent']"));
		executeTheScript("arguments[0].click();", locateElement(Locators.XPATH, "//p[text()='Individuals']"));
		//WebElement scroll = driver.findElement(By.xpath("//p[text()='Party Consent']"));
		//click(locateElement(Locators.XPATH, "//p[text()='Individuals']"));
		reportStep("Individuals Link is clicked", "pass");
		return new IndividualPage();
	} 
	/*
	 * public LoginPage clickLogOut() { click(locateElement(Locators.CLASS_NAME,
	 * "decorativeSubmit")); reportStep("Logout button is clicked", "pass"); return
	 * new LoginPage();
	 * 
	 * }
	 */

}
