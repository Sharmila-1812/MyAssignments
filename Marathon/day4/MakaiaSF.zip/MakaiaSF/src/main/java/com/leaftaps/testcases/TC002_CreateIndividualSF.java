package com.leaftaps.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.leaftaps.pages.SFLoginPage;

public class TC002_CreateIndividualSF extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
		testcaseName = "SFCreateIndividual";
		testDescription ="Verify that the Individual is created";
		authors="Sharmila";
		category ="Functional";
		excelFileName="CreateIndi";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String uname,String pass,String lastName) {
	SFLoginPage lp=new SFLoginPage();
	lp.enterUsername(uname)
	.enterPassword(pass)
	.clickLogin()
	.verifyHomePage()
	.clickToggleMenu()
	.clickViewAll()
	.clickIndividuals()
	.clickIndividualDropdown()
	.clickNewIndividual()
	.enterLastName(lastName)
	.clickSaveButton()
	.verifyMessage(lastName);
	
	}

}
