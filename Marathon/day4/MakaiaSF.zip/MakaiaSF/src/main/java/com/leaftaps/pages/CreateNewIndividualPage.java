package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class CreateNewIndividualPage extends ProjectSpecificMethods {
	public CreateNewIndividualPage enterLastName(String lName) {
		clearAndType(locateElement(Locators.XPATH, "//input[contains(@class,'lastName compound')]"), lName);
		reportStep(lName+" last name is entered successfully","pass");
		return this;
	}
	
	public ViewIndividualPage clickSaveButton() {
		click(locateElement(Locators.XPATH, "(//span[text()='Save'])[2]"));
		reportStep("Save is clicked successfully", "pass");
		return new ViewIndividualPage();
	}

}
