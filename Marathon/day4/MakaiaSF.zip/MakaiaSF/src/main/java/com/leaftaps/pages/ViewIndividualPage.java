package com.leaftaps.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class ViewIndividualPage extends ProjectSpecificMethods {

	public ViewIndividualPage verifyMessage(String lName) {
		verifyPartialText(locateElement(Locators.XPATH,
				"//span[@class='toastMessage slds-text-heading--small forceActionsText']"), lName);
		reportStep("Individual Verified Successfully", "pass");
		return this;
	}

}
