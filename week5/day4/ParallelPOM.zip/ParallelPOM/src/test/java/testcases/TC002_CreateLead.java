package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC002_CreateLead extends ProjectSpecificMethod {
	@Test(dataProvider = "sendData")
	public void runCreateLead(String username,String pwd,String cname,String fname,String lname) {
		
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(pwd)
		.clickLogin()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterCompanyName(cname)
		.enterFirstName(fname)
		.enterLastName(lname)
		.clickCreateLeadBtn()
		.getLeadId();
		
	}
	@BeforeTest
	public void setData() {
		fileName = "CreateLead";
	}

}
