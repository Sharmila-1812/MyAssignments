package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreateAccountPage extends ProjectSpecificMethod {

	public CreateAccountPage(ChromeDriver driver) {
		this.driver = driver;
	}

	public  CreateAccountPage enterAccountName(String AccName) {
		driver.findElement(By.id("accountName")).sendKeys(AccName);
		return this;
	}
	
	public CreateAccountPage enterDescription(String Description) {
		driver.findElement(By.name("description")).sendKeys(Description);
		return this;
		
	}
	public CreateAccountPage  enterNo_of_Employees(String EmpCount) {
		driver.findElement(By.id("numberEmployees")).sendKeys(EmpCount);
		return this;
	}
	public CreateAccountPage enterSiteName(String siteName) {
		driver.findElement(By.id("officeSiteName")).sendKeys(siteName);
		return this;
	}
	
	public AccountDetailsPage clickCreateAccountBtn() {
	driver.findElement(By.className("smallSubmit")).click();
	return new AccountDetailsPage(driver);
	}
	
}

