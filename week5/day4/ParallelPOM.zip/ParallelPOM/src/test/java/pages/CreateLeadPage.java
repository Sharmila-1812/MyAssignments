package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod{

	public CreateLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}

	public CreateLeadPage enterCompanyName(String cname) {
	
		driver.findElement(By.xpath("//input[@id='createLeadForm_companyName']")).sendKeys(cname); // Attribute

		return this;
	}
	
	public CreateLeadPage enterFirstName(String fname) {
		driver.findElement(By.xpath("(//input[contains(@id,'firstName')])[1]")).sendKeys(fname);// Partial
		
		return this;
	}
	
	public CreateLeadPage enterLastName(String lname) {
		driver.findElement(By.xpath("//input[contains(@id,'lastName')]")).sendKeys(lname);
		
		return this;
	}
	
	public ViewLeadPage clickCreateLeadBtn() {
		driver.findElement(By.xpath("//input[contains(@value,'Create Lead')]")).click();
		return new ViewLeadPage(driver);
	}
	
	
	
}
