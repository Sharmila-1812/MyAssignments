package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage(ChromeDriver driver) {
		this.driver = driver;		
	}


	public LoginPage enterUsername(String username) {
		
		driver.findElement(By.id("username")).sendKeys(username);
		
//		LoginPage lp = new LoginPage();
//		return lp;
		
//		return new LoginPage();
		
		return this;
	}
	
	
	public LoginPage enterPassword(String password) {
		
		driver.findElement(By.id("password")).sendKeys(password);
		return this;
	}
	
	
	public WelcomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		
		return new WelcomePage(driver);
	}
	
}
